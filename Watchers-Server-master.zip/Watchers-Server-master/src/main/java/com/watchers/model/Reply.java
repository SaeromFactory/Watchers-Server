package com.watchers.model;

public class Reply {
    private Integer Rnum;
    private Integer idx; // 게시글 번호
    private String Replytext;
    private String Replyid; // 댓글 작성자
    private Date Replydate; // 댓글 작성일자
    private Date ReUpdate; // 댓글 수정일자

    public Integer getRnum() {
        return Rnum;
    }

    public void setRnum(Integer rnum) {
        Rnum = rnum;
    }

    public Integer getIdx() {
        return idx;
    }

    public void setIdx(Integer idx) {
        this.idx = idx;
    }

    public String getReplytext() {
        return Replytext;
    }

    public void setReplytext(String replytext) {
        Replytext = replytext;
    }

    public String getReplyid() {
        return Replyid;
    }

    public void setReplyid(String replyid) {
        Replyid = replyid;
    }

    public Date getReplydate() {
        return Replydate;
    }

    public void setReplydate(Date replydate) {
        Replydate = replydate;
    }

    public Date getReUpdate() {
        return ReUpdate;
    }

    public void setReUpdate(Date reUpdate) {
        ReUpdate = reUpdate;
    }
}
