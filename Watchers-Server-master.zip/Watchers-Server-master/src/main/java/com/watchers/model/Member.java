package com.watchers.model;

public class Member {
}
