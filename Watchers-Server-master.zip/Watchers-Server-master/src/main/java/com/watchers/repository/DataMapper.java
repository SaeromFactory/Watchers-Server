package com.watchers.repository;

public interface DataMapper {
}
