package com.watchers.repository;

import com.watchers.model.Member;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;
import java.util.List;

@Mapper
@Component
public interface MemberMapper {

    public List<Member> memberList();
    public Member memberDetail(String id);
    public void updateMember(Member member);
}
