package com.watchers.repository;

import com.watchers.model.Board;
import com.watchers.model.Reply;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import java.util.List;

@Mapper
@Component
public interface ReplyMapper {

    public List<Reply> list(Board idx);
    // 댓글 목록
    public void put(Reply reply);
    // 댓글 입력
    public void update(Reply reply);
    // 댓글 수정
    public void delete(Reply Rnum);
    // 댓글 삭제
}
