package com.watchers.service;

import org.apache.catalina.servlet4preview.http.HttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class AdminService extends HandlerInterceptorAdaptor {

    // 요청 실행 전
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception{
        HttpSession session = request.getSession();

        if(session.getAttribute("userEnum") == "C"){
            // 사용자 화면으로 되돌리기 -> 경로 확인 후 수정
            response.sendRedirect(request.getContextPath() + "/login");
            return false;
        }else{
            // 요청 실행하기 !
            return true;
        }
    }

    // 요청 실행 후
    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
                           ModelAndView modelAndView) throws Exception{
        super.postHandle(request, response, handler, modelAndView);
    }
}
