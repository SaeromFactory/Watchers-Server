package com.watchers.service;

import com.watchers.model.Board;
import com.watchers.model.Reply;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
@Component
public class ReplyService {
    @Autowired priavate ReplyMapper replymapper;

    public List<Reply> list(int idx){
        return Board.list(idx);
    }

    public void put(Reply reply){
        Reply.setRnum(reply);
    }

    public void update(Reply reply){

    }

    public void delete(int Rnum){

    }

}
