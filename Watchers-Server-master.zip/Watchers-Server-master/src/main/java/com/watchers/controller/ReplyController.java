package com.watchers.controller;

import com.fasterxml.jackson.annotation.JacksonInject;
import com.watchers.model.Reply;
import com.watchers.service.ReplyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;

@RestController // 화면 전환 위해
@RequestMapping("/list/{page}/*/reply")
public class ReplyController {

    @Autowired
    ReplyService replyService;
/*
    public void reply(HttpSession session, Reply reply){
        if(session.getAttribute("id")!=null){
            //로그인을 함

        }
        else{
            //로그인을 안함
        }
    }
*/

    @RequestMapping("/put")
    public void put(@ModelAttribute Reply reply, HttpSession session){
        String id = (String)session.getAttribute("userId");
        reply.setReplyid(id);
        replyService.put(reply);
    }

    // 댓글 목록 화면 리턴 ... 데이터는 ?
    @RequestMapping("/")
    public ModelAndView list(@RequestParam int idx, ModelAndView mav){
        List<Reply> list = replyService.list(idx);
        mav.setViewName("board/replyList"); // 뷰에 전달한 데이터 다시 지정
        mav.addObject("list", list);
        return mav;
    }

}

