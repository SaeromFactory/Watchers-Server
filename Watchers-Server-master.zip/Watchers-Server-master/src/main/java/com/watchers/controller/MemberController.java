package com.watchers.controller;

import com.watchers.model.Member;
import com.watchers.service.MemberService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MemberController {
    private static final Logger logger = LoggerFactory.getLogger(MemberController.class);

    @Autowired
    MemberService memberservice;

    // 회원 목록
    @RequestMapping("member/list.do")
    public String memberList(Model model){
        List<Member> list = memberservice.memberList();
        model.addAttribute("list", list);
        return "member/member_list";
    }

    // 회원 상세 정보 조회 (작성 게시글 포함)
    @RequestMapping("member/detail.do")
    public String memberDetail(String id, Model model){
        // 회원 정보를 전부 model에 저장해놓기
        model.addAttribute("member", memberservice.detailMember(id));
        logger.info("선택한 아이디 : " + id);
        return "member/detail.do";
    }

    // 회원 정보 수정
    @RequestMapping("member/update.do")
    public String memberUpdate(@ModelAttribute Model model){
        memberervice.updateMember(model);
        return "redirect:/member/member_list";
    }
}
