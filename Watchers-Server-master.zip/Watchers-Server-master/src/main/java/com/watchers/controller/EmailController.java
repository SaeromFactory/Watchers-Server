package com.watchers.controller;

import com.watchers.model.Email;
import com.watchers.model.Users;
import com.watchers.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class EmailController {

    @Autowired
    private EmailService emailservice;

    @Autowired
    private Email email;

    @RequestMapping("/sendpw.do")
    public ModelAndView sendEmailAndView(@RequestParam Users<String, object> users)throws Exception {
        ModelAndView mav;
        String id = users.getId();
        String email = users.getEmail();
        String pw = users.getPw();

        System.out.println(pw);

        if(pw!=null){
            email.setContent("비밀번호는 " + pw + " 입니다.");
            email.setReceiver(email);
            email.setSubject(id + " 사용자의 비밀번호 찾기 메일입니다.");
            mav = new ModelAndView("redirect:/login.do");
            return mav;
        }else{
            mav = new ModelAndView("redirect:/logout.do");
            return mav;
        }

        System.out.println(pw);
    }
}
