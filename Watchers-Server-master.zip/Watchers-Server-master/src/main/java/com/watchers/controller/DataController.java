package com.watchers.controller;

import com.watchers.service.DataService;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;

@RequestMapping("Datas")
@RestController
public class DataController {

}
